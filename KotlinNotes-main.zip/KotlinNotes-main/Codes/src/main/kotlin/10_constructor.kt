fun main() {
    var car  = autoMobile("Car",4,789)
    val person = person()
}

class autoMobile(val name:String, val tyres:Int, val maxSeating : Int){
    fun drive(){

    }
    fun applyBrake(){

    }
}

class person(){
    val name:String = ""
    val age:Int = 0

}