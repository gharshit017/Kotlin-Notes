fun main() {
    println("Myself Om Prakash")
    println("Myself Om Prakash")
    print(1+2)
    /* Two Types of variable 
      :- 1. Var  & 2. Val
      	Var can be changed but Val can't be changed (work as a const)
        */
    println(false)
    var a = 71111
    println(a)
    val b = 89
    println(b)
    //b = 897     This is Wrong
    println(a)
    
    // While assigning float in a it gives error (Type checking)
    // var a = 8.1    (Error  We can't assign float 
    // 
    
    
    // WE can assign variable a:-
    var num : Int = 9876
    var avg : Double = 9887.9
    var check : Boolean = false
    var favChar : Char = 'A';
    var name : String = "Name";
    println(check)
}