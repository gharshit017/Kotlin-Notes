fun main (){
    val num = 5
//    val check = num in 1..5
    val check = num in 1 until 5
    println(check)
    println(num)
}
