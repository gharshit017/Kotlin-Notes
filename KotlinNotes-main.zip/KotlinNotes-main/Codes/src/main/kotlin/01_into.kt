fun main() {
/*  What is Kotlin?
-> New Programming language by Jetbrains (MODERN replacement of Java )
	JetBrains devloped softwares like Android STUDIO, Intellij Idea m Pycharm etc.
	Target JVM, Abdroid , Native & JavaScript.

HISTORY OF KOTLIN 
	> In 2011, JetBrains announced the devlopment of kotlin
	> Made it open source
	> 1.0 was live in 2016
	> Google IO 2017, Andriod's first class support for kotlin.
	> In 2019, Android is now Kotlin First.

FEATURES OF KOTLIN
	> Statically Typed Language( Check during compile time )
	> Object Oriented and Functional Language
	> 100% interoperable with Java (we can use both Java & Kotlin in Same project )
	> Concise, Safe and Powerful

*/
    val num = 10;
    println(num)

}